#include <stdio.h>
int main()
{
    int p = 1000;
    int r = 0.05;
    int t = 2;
    int interest = p*r*t/100;
    
    int height = 10;
    int base = 12;
    int area = height*base/2;
    
    printf("Interest for %d at rate %d for %d years will be %d",p,r,t,interest);
    printf("Area of triangle with base %d and height %d will be %d",height,base,area);
    return 0;
}
