#include <stdio.h>

int main(){
	int i = 3*3/4-3+8;
	int a = i + 4;	
	
	if(a>10){	
		a = a-10;
	} 

	return 0;
}